/**<!DOCTYPE suite SYSTEM "https://testng.org/testng-1.0.dtd" >
<suite name="FST_TestNG Suite">
<test name="TestNG Training">
<classes>
<class name="Activity1" />
<class name="Activity2" />
<class name="Activity3" />
<class name="Activity4" />
<class name="Activity5" />
<class name="Activity6" />
<class name="Activity7" />
</classes>
</test>
</suite>
**/