/***<!DOCTYPE suite SYSTEM "https://testng.org/testng-1.0.dtd" >
<suite name="FST_TestNG Suite">
<test name="TestNG Training">
<classes>
<class name="Activity1" />
<class name="Activity2" />
</classes>
</test>
</suite>
***/