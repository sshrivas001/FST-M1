Number = int(input ("Enter a number:"))
if Number%2 == 0:
    print("Number is even")
else:
    print("Number is odd")